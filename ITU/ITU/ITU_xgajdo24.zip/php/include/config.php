<?php
/*
 * Konfiguracni soubor.
 * Zde nastavte pripojeni do databaze
 * $servername = 'MySQL server'
 * $username = 'uzivatelske jmeno pro pristup k databazi';
 * $password = 'heslo pro pristup k databazi';
 * $databasename = 'nazev databaze';
 *
 *
 * Priklad:
 * $servername = 'localhost';
 * $username = 'root';
 * $password = '';
 * $password = '';
 * $databasename = 'db1';
 *
 *
*/

$servername = 'localhost'; 
$username = "xmarek69";
$password = "8afunope";

$databasename = "xmarek69";


?>