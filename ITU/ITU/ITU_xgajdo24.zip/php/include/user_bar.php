
<div id="user_bar">
    <a href="index.php?akce=nastaveni"><img src="img/settings.png"></a>    
    <a href="php/include/logout.php"><img src="img/logout.png"></a>
</div>