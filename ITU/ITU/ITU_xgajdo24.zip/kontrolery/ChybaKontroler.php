<!---Autoři: xmarek69, xbilid01, xgajdo24 --->
<?php

class ChybaKontroler extends Kontroler
{
    public function zpracuj($parametry)
    {
		// Hlavièka požadavku
		header("HTTP/1.0 404 Not Found");
		// Nastavení šablony
		$this->pohled[0] = 'chyba';
    }
}
?>