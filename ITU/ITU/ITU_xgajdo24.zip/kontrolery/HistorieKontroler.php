<!---Auto�i: xmarek69, xbilid01, xgajdo24 --->
<?php

class HistorieKontroler extends Kontroler
{
	// Instance controlleru
	protected $kontroler;
	


    // Naparsov�n�� URL adresy a vytvo�en�� p���slu�n�ho controlleru
    public function zpracuj($parametry)
    {
        $spravceZbozi = new SpravceZbozi();

        $spravceNastaveni = new SpravceNastaveni();
        $nastaveni = $spravceNastaveni->vratNastaveni($parametry['id']);
        $this->data['nastaveni'] = $nastaveni;

        $dodavky = $spravceZbozi->vratDodavkuPodlePodminky($parametry['id'], "", "");
        $this->data['dodavky'] = $dodavky;
        
		$this->pohled[0] = 'historie';
		
    }

   

}
?>