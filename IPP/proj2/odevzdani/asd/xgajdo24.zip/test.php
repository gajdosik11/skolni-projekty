<?php
	echo "Nedokazal jsem dokoncit implementaci";
?>